<?php
declare(strict_types=1);

namespace App\Controller;

use Authentication\Controller\Component\AuthenticationComponent;

class UsersController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();

        $this->loadComponent('Authentication.Authentication');

        // Permitir acceso sin login
        $this->Authentication->allowUnauthenticated(['login', 'add']);
    }

    // 🔐 LOGIN
    public function login()
    {
        $this->request->allowMethod(['get', 'post']);

        $result = $this->Authentication->getResult();

        if ($result->isValid()) {
            //return $this->redirect(['action' => 'index']);
		return $this->redirect(['controller' => 'Servicios', 'action' => 'index']);
        }

        if ($this->request->is('post') && !$result->isValid()) {
            $this->Flash->error('Correo o contraseña incorrectos');
        }
    }

    // 🚪 LOGOUT
    public function logout()
    {
        $this->Authentication->logout();
        return $this->redirect(['action' => 'login']);
    }

    // 📋 LISTAR
    public function index()
    {
        $query = $this->Users->find();
        $users = $this->paginate($query);

        $this->set(compact('users'));
    }

    // 👁 VER
    public function view($id = null)
    {
        $user = $this->Users->get($id);
        $this->set(compact('user'));
    }

    // ➕ CREAR (REGISTRO)
    public function add()
    {
        $user = $this->Users->newEmptyEntity();

        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());

            if ($this->Users->save($user)) {
                $this->Flash->success('Usuario registrado correctamente');
                return $this->redirect(['action' => 'login']);
            }

            $this->Flash->error('No se pudo registrar el usuario');
        }

        $this->set(compact('user'));
    }

    // ✏️ EDITAR
    public function edit($id = null)
    {
        $user = $this->Users->get($id);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());

            if ($this->Users->save($user)) {
                $this->Flash->success('Usuario actualizado');
                return $this->redirect(['action' => 'index']);
            }

            $this->Flash->error('No se pudo actualizar');
        }

        $this->set(compact('user'));
    }

    // ❌ ELIMINAR
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);

        $user = $this->Users->get($id);

        if ($this->Users->delete($user)) {
            $this->Flash->success('Usuario eliminado');
        } else {
            $this->Flash->error('No se pudo eliminar');
        }

        return $this->redirect(['action' => 'index']);
    }
}