<?php
declare(strict_types=1);

/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc.
 *
 * Licensed under The MIT License
 */

namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\EventInterface;

class AppController extends Controller
{
    public function initialize(): void
    {
        parent::initialize();

        $this->loadComponent('Flash');

        // 🔐 Autenticación
        $this->loadComponent('Authentication.Authentication');

        // ✅ Acceso sin login SOLO a login y registro
        $this->Authentication->allowUnauthenticated([
            'login',
            'add'
        ]);

        /*
         * Protección de formularios (opcional)
         */
        //$this->loadComponent('FormProtection');
    }

    // 🔒 CONTROL GLOBAL DE ACCESO (CORREGIDO)
    public function beforeFilter(EventInterface $event)
    {
        parent::beforeFilter($event);

        $currentController = $this->request->getParam('controller');
        $currentAction = $this->request->getParam('action');

        // 🚨 Evitar bucle infinito
        if (
            !$this->request->getAttribute('identity') &&
            !($currentController === 'Users' && in_array($currentAction, ['login', 'add']))
        ) {
            return $this->redirect([
                'controller' => 'Users',
                'action' => 'login'
            ]);
        }
    }
}