<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Servicios Model
 *
 * @method \App\Model\Entity\Servicio newEmptyEntity()
 * @method \App\Model\Entity\Servicio newEntity(array $data, array $options = [])
 * @method array<\App\Model\Entity\Servicio> newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Servicio get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \App\Model\Entity\Servicio findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \App\Model\Entity\Servicio patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\App\Model\Entity\Servicio> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Servicio|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \App\Model\Entity\Servicio saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\App\Model\Entity\Servicio>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Servicio>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Servicio>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Servicio> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Servicio>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Servicio>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Servicio>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Servicio> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ServiciosTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('servicios');
        $this->setDisplayField('nombre');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('nombre')
            ->maxLength('nombre', 150)
            ->requirePresence('nombre', 'create')
            ->notEmptyString('nombre');

        $validator
            ->integer('duracion_min')
            ->requirePresence('duracion_min', 'create')
            ->notEmptyString('duracion_min');

        $validator
            ->decimal('precio')
            ->requirePresence('precio', 'create')
            ->notEmptyString('precio');

        $validator
            ->scalar('descripcion')
            ->allowEmptyString('descripcion');

        $validator
            ->scalar('estado')
            ->allowEmptyString('estado');

        return $validator;
    }
}
