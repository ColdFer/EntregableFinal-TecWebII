<?php
declare(strict_types=1);

namespace App;

use Cake\Core\Configure;
use Cake\Core\ContainerInterface;
use Cake\Datasource\FactoryLocator;
use Cake\Error\Middleware\ErrorHandlerMiddleware;
use Cake\Event\EventManagerInterface;
use Cake\Http\BaseApplication;
use Cake\Http\Middleware\BodyParserMiddleware;
use Cake\Http\Middleware\CsrfProtectionMiddleware;
use Cake\Http\MiddlewareQueue;
use Cake\ORM\Locator\TableLocator;
use Cake\Routing\Middleware\AssetMiddleware;
use Cake\Routing\Middleware\RoutingMiddleware;

// 🔐 Authentication
use Authentication\AuthenticationService;
use Authentication\AuthenticationServiceInterface;
use Authentication\AuthenticationServiceProviderInterface;
use Authentication\Middleware\AuthenticationMiddleware;
use Psr\Http\Message\ServerRequestInterface;

class Application extends BaseApplication implements AuthenticationServiceProviderInterface
{
    public function bootstrap(): void
    {
        parent::bootstrap();
	$this->addPlugin('Authentication');

        FactoryLocator::add('Table', (new TableLocator())->allowFallbackClass(false));
    }

    // 🔐 Configuración de autenticación
    public function getAuthenticationService(ServerRequestInterface $request): AuthenticationServiceInterface
{
    $service = new AuthenticationService([
        'unauthenticatedRedirect' => '/users/login',
        'queryParam' => 'redirect',

        // 🔐 IDENTIFICADOR AQUÍ (NO loadIdentifier)
        'identifiers' => [
            'Authentication.Password' => [
                'fields' => [
                    'username' => 'correo',
                    'password' => 'password',
                ],
            ],
        ],

        // 🔐 AUTHENTICATORS
        'authenticators' => [
            'Authentication.Session',
            'Authentication.Form' => [
                'fields' => [
                    'username' => 'correo',
                    'password' => 'password',
                ],
                'loginUrl' => '/users/login',
            ],
        ],
    ]);

    return $service;
}

    // 🔥 Middleware (AQUÍ VA LO IMPORTANTE)
    public function middleware(MiddlewareQueue $middlewareQueue): MiddlewareQueue
    {
        $middlewareQueue
            ->add(new ErrorHandlerMiddleware(Configure::read('Error'), $this))

            ->add(new AssetMiddleware([
                'cacheTime' => Configure::read('Asset.cacheTime'),
            ]))

            ->add(new RoutingMiddleware($this))

            // 🔐 PROTECCIÓN GLOBAL
            ->add(new AuthenticationMiddleware($this))

            ->add(new BodyParserMiddleware())

            ->add(new CsrfProtectionMiddleware([
                'httponly' => true,
            ]));

        return $middlewareQueue;
    }

    public function services(ContainerInterface $container): void
    {
    }

    public function events(EventManagerInterface $eventManager): EventManagerInterface
    {
        return $eventManager;
    }
}