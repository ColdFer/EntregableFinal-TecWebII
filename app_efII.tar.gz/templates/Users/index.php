<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\User> $users
 */
?>
<div class="users index content">
    <?= $this->Html->link(__('New User'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Users') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('nombre') ?></th>
                    <th><?= $this->Paginator->sort('apellido') ?></th>
                    <th><?= $this->Paginator->sort('edad') ?></th>
                    <th><?= $this->Paginator->sort('correo') ?></th>
                    <th><?= $this->Paginator->sort('language') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= $this->Number->format($user->id) ?></td>
                    <td><?= h($user->nombre) ?></td>
                    <td><?= h($user->apellido) ?></td>
                    <td><?= $user->edad === null ? '' : $this->Number->format($user->edad) ?></td>
                    <td><?= h($user->correo) ?></td>
                    <td><?= h($user->language) ?></td>
                    <td><?= h($user->created) ?></td>
                    <td><?= h($user->modified) ?></td>
                    <td class="actions" style="white-space:nowrap;">

		    <?= $this->Html->link('👁️', ['action' => 'view', $user->id], [
			'title' => 'Ver',
			'style' => 'margin-right:10px; font-size:18px; text-decoration:none;'
		    ]) ?>

		    <?= $this->Html->link('✏️', ['action' => 'edit', $user->id], [
			'title' => 'Editar',
			'style' => 'margin-right:10px; font-size:18px; text-decoration:none;'
		    ]) ?>

		    <?= $this->Form->postLink(
			'🗑️',
			['action' => 'delete', $user->id],
			[
			    'method' => 'delete',
			    'confirm' => __('Are you sure you want to delete # {0}?', $user->id),
			    'title' => 'Eliminar',
			    'style' => 'font-size:18px; color:red; text-decoration:none;'
			]
		    ) ?>

		</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>