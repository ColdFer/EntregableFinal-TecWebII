<h2>Login</h2>

<?= $this->Form->create() ?>
<?= $this->Form->control('correo') ?>
<?= $this->Form->control('password') ?>
<?= $this->Form->button('Ingresar') ?>
<?= $this->Form->end() ?>

<p>
<?= $this->Html->link('Registrarse', ['action' => 'add']) ?>
</p>