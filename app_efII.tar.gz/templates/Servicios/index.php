<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Servicio> $servicios
 */
?>
<div class="servicios index content">
    <?= $this->Html->link(__('New Servicio'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Servicios') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('nombre') ?></th>
                    <th><?= $this->Paginator->sort('duracion_min') ?></th>
                    <th><?= $this->Paginator->sort('precio') ?></th>
                    <th><?= $this->Paginator->sort('estado') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($servicios as $servicio): ?>
                <tr>
                    <td><?= $this->Number->format($servicio->id) ?></td>
                    <td><?= h($servicio->nombre) ?></td>
                    <td><?= $this->Number->format($servicio->duracion_min) ?></td>
                    <td><?= $this->Number->format($servicio->precio) ?></td>
                    <td><?= h($servicio->estado) ?></td>
                    <td><?= h($servicio->created) ?></td>
                    <td><?= h($servicio->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $servicio->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $servicio->id]) ?>
                        <?= $this->Form->postLink(
                            __('Delete'),
                            ['action' => 'delete', $servicio->id],
                            [
                                'method' => 'delete',
                                'confirm' => __('Are you sure you want to delete # {0}?', $servicio->id),
                            ]
                        ) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>