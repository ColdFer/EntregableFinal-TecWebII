<?php
/**
 * @var \App\View\AppView $this
 */
?>
<!DOCTYPE html>
<html>
<head>
    <?= $this->Html->charset() ?>
    <title>Mi Aplicación</title>
    <?= $this->Html->meta('icon') ?>

    <?= $this->Html->css(['normalize.min', 'milligram.min', 'cake']) ?>

    <?= $this->fetch('meta') ?>
    <?= $this->fetch('css') ?>
</head>

<body>

<?php if ($this->request->getAttribute('identity')): ?>

<!-- 🔥 NAVBAR SUPERIOR -->
<nav style="background:#2c3e50;padding:10px; display:flex; justify-content:space-between; align-items:center;">
    
    <!-- IZQUIERDA -->
    <div>
        <a href="<?= $this->Url->build('/servicios') ?>" style="color:white;margin-right:15px;">Servicios</a>
        <a href="<?= $this->Url->build('/users') ?>" style="color:white;margin-right:15px;">Usuarios</a>
    </div>

    <!-- DERECHA -->
    <div style="display:flex; align-items:center; gap:15px;">
        <span style="color:white;">
            👤 <?= $this->request->getAttribute('identity')->correo ?>
        </span>

        <?= $this->Form->postLink(
            'Cerrar sesión',
            ['controller' => 'Users', 'action' => 'logout'],
            [
                'style' => '
                    background:#e74c3c;
                    color:white;
                    padding:6px 12px;
                    border-radius:5px;
                    text-decoration:none;
                    font-weight:bold;
                    border:none;
                ',
                'confirm' => '¿Deseas cerrar sesión?'
            ]
        ) ?>
    </div>

</nav>

<?php endif; ?>

<!-- 🔹 CONTENIDO -->
<main class="main">
    <div class="container">

        <!-- MENSAJES FLASH -->
        <?= $this->Flash->render() ?>

        <!-- CONTENIDO DE VISTAS -->
        <?= $this->fetch('content') ?>

    </div>
</main>

<!-- 🔹 FOOTER -->
<footer style="text-align:center; padding:10px; margin-top:20px; color:#777;">
    <small>Proyecto - Tecnología Web II</small>
</footer>

</body>
</html>